<?php

namespace App\Controllers;

use App\Models\tugasmodel;

class tugas extends BaseController
{
	protected $tugasmodel;
	
	public function __construct()
    {
        $this->tugasmodel = new tugasmodel();
    }
	
    public function index()
    {
		$data = $this->tugasmodel
		->findAll();
		
        return view('index', ['data' => $data]);
    }
	
	public function create(){
		return view('create');
	}
	
	public function store(){
		$nama = $this->request->getPost('nama');
		$prioritas = $this->request->getPost('prioritas');
		$deadline = $this->request->getPost('deadline');
		
		$store = [
			'nama_tugas' => $nama,
			'prioritas' => $prioritas,
			'deadline' => $deadline
		];
		
		$store['status'] = 'belum';
		
		$this->tugasmodel->insert($store);
		return redirect()->to('/');
	}
	
	public function edit($id = null){
		$data = $this->tugasmodel->find($id);
		return view('edit', ['data' => $data]);
	}
	
	public function update($id = null){
		$nama = $this->request->getPost('nama');
		$prioritas = $this->request->getPost('prioritas');
		$deadline = $this->request->getPost('deadline');
		
		$update = [
			'nama_tugas' => $nama,
			'prioritas' => $prioritas,
			'deadline' => $deadline
		];
		
		$this->tugasmodel->update($id, $update);
		return redirect()->to('/');
	}
	
	public function delete($id = null){
		$this->tugasmodel->delete($id);
		return redirect()->back();
	}
	
	public function status($id = null){
		$data = $this->tugasmodel->find($id);
		
		$statuskondisi = ($data['status'] == 'belum') ? 'selesai' : 'belum';
		
		$statusupdate = [
		'status' => $statuskondisi
		];
		
		$this->tugasmodel->update($id, $statusupdate);
		return redirect()->back();
	}
}
