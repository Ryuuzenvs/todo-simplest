<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'tugas::index');

$routes->get('/create', 'tugas::create');

$routes->post('/store', 'tugas::store');

$routes->get('/edit/(:num)', 'tugas::edit/$1');

$routes->post('/update/(:num)', 'tugas::update/$1');

$routes->get('/delete/(:num)', 'tugas::delete/$1');
$routes->get('/status/(:num)', 'tugas::status/$1');