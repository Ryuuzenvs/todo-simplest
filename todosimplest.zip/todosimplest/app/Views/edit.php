<head>
<link href=<?= base_url('assets/dist/css/bootstrap.min.css')?> rel="stylesheet">
</head>

<body background=<?=base_url('img103.png')?>>
<div class="d-flex justify-content-center align-items-center vh-100">

<form action="<?=base_url('update/' . $data['id'])?>" method="post" 
class="p-4"
style="background-color: rgba(255,255,255,0.7)">

<div class="form-group">
<label for="nama" class="text-center">nama</label>
<input id="nama" name="nama" type="nama" class="form-control" value="<?= $data['nama_tugas']?>" required>
</div>

<div class="form-group">
<label for="prioritas">prioritas</label>
<select class="form-select" id="prioritas" name="prioritas">
<option value="cukup" <?= ($data['prioritas'] == 'cukup')  ? 'selected' : '' ?>>cukup</option>
<option value="biasa" <?= ($data['prioritas'] == 'biasa') ? 'selected' : '' ?>>biasa</option>
<option value="penting" <?= ($data['prioritas']=='penting') ? 'selected' : '' ?>>penting</option>
</select>
</div>

<div class="form-group">
<label for="deadline" class="text-center">deadline</label>
<input id="deadline" name="deadline" type="date"class="form-control" value="<?= $data['deadline']?>" required>
</div>

<div class="d-grid mt-3">
<button type="submit" class="btn btn-success">update</button>
<a class="btn btn-primary btn-sm mt-2" href="<?= base_url('/')?>">
back
</a>
</div>


</form>

</div>


</body>