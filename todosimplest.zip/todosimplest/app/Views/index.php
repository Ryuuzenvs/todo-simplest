<head>
<link href=<?= base_url('assets/dist/css/bootstrap.min.css')?> rel="stylesheet">
</head>

<body>

<table class="table table-stripped">

<thead>

<th>nama</th>
<th>prioritas</th>
<th>deadline</th>
<th></th>

</thead>

<?php foreach($data as $d) : ?>
<tbody>
<tr>

<td><?= ($d['nama_tugas'])?></td>
<td><?= ($d['prioritas'])?></td>
<td><?= ($d['deadline'])?></td>
<td>
<a class="btn btn-warning btn-sm" href="<?=base_url('edit/' . $d['id'])?>">edit</a>
<?php 
$statusbtn = ($d['status'] == 'belum') ? 'danger' : 'success';
$statusaja = ($d['status'] == 'belum') ? 'belum' : 'selesai';
?>
<a 
class="btn btn-<?=$statusbtn?> btn-sm"
href="<?=base_url('status/'.$d['id'])?>"
>
<?=$statusaja?>

</a>
<a	
class="btn btn-danger btn-sm"
href="<?= base_url('delete/' . $d['id'])?>"
>
hapus
</a>
</td>
<?php endforeach;?>
</tr>
</tbody>

</table>
<a class="btn btn-primary btn-sm" href="<?= base_url('create')?>">
create
</a>
</body>